CREATE PROCEDURE my_procedure(IN v1 VARCHAR(255))
  BEGIN

      SELECT * FROM Orders WHERE order_num=v1; 


   END;
