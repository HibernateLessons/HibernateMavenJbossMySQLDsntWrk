CREATE PROCEDURE `First proc`(IN p1 VARCHAR(255))
  BEGIN

  SELECT * FROM Orders WHERE order_num = p1;

END;
