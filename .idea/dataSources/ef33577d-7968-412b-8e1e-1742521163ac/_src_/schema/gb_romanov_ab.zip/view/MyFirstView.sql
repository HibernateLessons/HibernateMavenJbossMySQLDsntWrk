CREATE VIEW MyFirstView AS
  SELECT
    `gb_romanov_ab`.`Orders`.`Id`        AS `Id`,
    `gb_romanov_ab`.`Orders`.`cust_id`   AS `cust_id`,
    `gb_romanov_ab`.`Orders`.`order_num` AS `order_num`
  FROM `gb_romanov_ab`.`Orders`
  WHERE (`gb_romanov_ab`.`Orders`.`order_num` = 'Test');
